// 运行控制变量
int bgChgInterval = 60;            // 背景变换时间间隔
int timeCheckInterval = 300;       // 时间更新时间间隔
int biliUpdateInterval = 650;      // 哔哩信息更新时间间隔
int weatherUpdateInterval = 900;   // 天气信息更新时间间隔
int weatherDisplayInterval = 5;    // 天气信息显示时间间隔

const int START_BG_NUM = 1;               // 起始图片编号
const int END_BG_NUM = 50;                // 终止图片编号
const int MAX_INFO_ID = 10;               // 屏幕下方显示信息数量
